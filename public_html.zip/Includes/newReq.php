<?php
$servername = "localhost";
$username = "idona_urban";
$password = "123456";
$dbname = "idona_urban";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";

$fname= $_POST["fname"]; 
$lname= $_POST["lname"];
$phone= $_POST["phone"];
$email= $_POST["email"]; 
$subject= $_POST["subject"];
$whatnew= $_POST["whatnew"];
$description= $_POST["description"];
$loc= $_POST["loc"];

$sql ="INSERT INTO `newrequest` (`fname`,`lname`,`phone`,`email`,`subject`,`whatnew`,`description`,`loc`)
VALUES ('$fname','$lname','$phone','$email','$subject','$whatnew','$description','$loc')";

if ($conn->query($sql) === TRUE) {
    //echo "New record created successfully";
    header("Location: success.php?fname=$fname");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

?>