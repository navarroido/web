function validateForm() {
  var x = document.forms["reqForm"]["description"].value;
  if (x == '')
  {
      alert("נא למלא את תאור הפנייה");
  }
  else{
    alert("תודה, ניצור איתך קשר בהקדם");
    return false;
  }
}