
var img1 =document.getElementById("img1");
var img2 =document.getElementById("img2");

function overMe()
{
	img1.src="img/noentry.png";
	
}

function overMe2()
{
	img2.src="img/noentry.png";
	
}

